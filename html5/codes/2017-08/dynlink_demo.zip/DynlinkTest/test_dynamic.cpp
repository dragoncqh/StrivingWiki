#include "stdafx.h"
#include "psapi_load.h"

void test_dynamic()
{
	_tprintf(_T("--TEST: Traditional dynamic loading (explicit)\r\n"));
	TEST(1 == psapi_load());

	TCHAR sName1[1024];
#ifdef UNICODE
	TEST(pGetProcessImageFileNameW(GetCurrentProcess(), sName1, 1024) > 0);
#else
	TEST(pGetProcessImageFileNameA(GetCurrentProcess(), sName1, 1024) > 0);
#endif
	_tprintf(_T("  exe path: %s\r\n"), sName1);
	_tprintf(_T("SUCCESS: ALL TESTS PASSED\r\n\r\n"));
}
