#include <psapi.h>
#include "LateLoad.h"

LATELOAD_BEGIN_CLASS(CPsapiWrapper,psapi,FALSE,TRUE)

LATELOAD_FUNC_3(FALSE,
BOOL,
WINAPI,
EnumProcesses,
    __out_bcount(cb) DWORD *,
    __in DWORD,
    __out LPDWORD
    )

LATELOAD_FUNC_4(FALSE,
BOOL,
WINAPI,
EnumProcessModules,
    __in  HANDLE,
    __out_bcount(cb) HMODULE,
    __in  DWORD,
    __out LPDWORD
    )

LATELOAD_FUNC_5(FALSE,
BOOL,
WINAPI,
EnumProcessModulesEx,
    __in  HANDLE,
    __out_bcount(cb)  HMODULE,
    __in  DWORD,
    __out  LPDWORD,
    __in  DWORD
    )

LATELOAD_FUNC_4(((DWORD)-1),
DWORD,
WINAPI,
GetModuleBaseNameA,
    __in HANDLE,
    __in_opt HMODULE,
    __out_ecount(nSize) LPSTR,
    __in DWORD
    )

LATELOAD_FUNC_4(((DWORD)-1),
DWORD,
WINAPI,
GetModuleBaseNameW,
    __in HANDLE,
    __in_opt HMODULE,
    __out_ecount(nSize) LPWSTR,
    __in DWORD
    )

LATELOAD_FUNC_4(((DWORD)-1),
DWORD,
WINAPI,
GetModuleFileNameExA,
     __in HANDLE,
    __in_opt HMODULE,
    __out_ecount(nSize) LPSTR,
    __in DWORD
    )

LATELOAD_FUNC_4(((DWORD)-1),
DWORD,
WINAPI,
GetModuleFileNameExW,
    __in HANDLE,
    __in_opt HMODULE,
    __out_ecount(nSize) LPWSTR,
    __in DWORD
    )

LATELOAD_FUNC_4(FALSE,
BOOL,
WINAPI,
GetModuleInformation,
	__in HANDLE,
    __in HMODULE,
    __out LPMODULEINFO,
    __in DWORD
    )


LATELOAD_FUNC_1(FALSE,
BOOL,
WINAPI,
EmptyWorkingSet,
     __in HANDLE
    )


LATELOAD_FUNC_3(FALSE,
BOOL,
WINAPI,
QueryWorkingSet,
    __in HANDLE,
    __out_bcount(cb) PVOID,
    __in DWORD
    )

LATELOAD_FUNC_3(FALSE,
BOOL,
WINAPI,
QueryWorkingSetEx,
    __in HANDLE,
    __out_bcount(cb) PVOID,
    __in DWORD
    )

LATELOAD_FUNC_1(FALSE,
BOOL,
WINAPI,
InitializeProcessForWsWatch,
    __in HANDLE
    )

LATELOAD_FUNC_3(FALSE,
BOOL,
WINAPI,
GetWsChanges,
    __in HANDLE,
    __out_bcount(cb) PPSAPI_WS_WATCH_INFORMATION,
    __in DWORD
    )

LATELOAD_FUNC_3(FALSE,
BOOL,
WINAPI,
GetWsChangesEx,
    __in HANDLE,
    __out_bcount_part(*cb, *cb) PPSAPI_WS_WATCH_INFORMATION_EX,
    __inout PDWORD
    )

LATELOAD_FUNC_4(((DWORD)-1),
DWORD,
WINAPI,
GetMappedFileNameW,
	__in HANDLE,
    __in LPVOID,
    __out_ecount(nSize) LPWSTR,
    __in DWORD
    )

LATELOAD_FUNC_4(((DWORD)-1),
DWORD,
WINAPI,
GetMappedFileNameA,
	__in HANDLE,
    __in LPVOID,
    __out_ecount(nSize) LPSTR,
    __in DWORD
    )

LATELOAD_FUNC_3(FALSE,
BOOL,
WINAPI,
EnumDeviceDrivers,
    __out_bcount(cb) LPVOID,
    __in DWORD,
    __out LPDWORD
    )


LATELOAD_FUNC_3(((DWORD)-1),
DWORD,
WINAPI,
GetDeviceDriverBaseNameA,
    __in LPVOID,
    __out_ecount(nSize) LPSTR,
    __in DWORD
    )

LATELOAD_FUNC_3(((DWORD)-1),
DWORD,
WINAPI,
GetDeviceDriverBaseNameW,
    __in LPVOID,
    __out_ecount(nSize) LPWSTR,
    __in DWORD
    )

LATELOAD_FUNC_3(((DWORD)-1),
DWORD,
WINAPI,
GetDeviceDriverFileNameA,
    __in LPVOID,
    __out_ecount(nSize) LPSTR,
    __in DWORD
    )

LATELOAD_FUNC_3(((DWORD)-1),
DWORD,
WINAPI,
GetDeviceDriverFileNameW,
    __in LPVOID,
    __out_ecount(nSize) LPWSTR,
    __in DWORD
    )


LATELOAD_FUNC_3(FALSE,
BOOL,
WINAPI,
GetProcessMemoryInfo,
    HANDLE ,
    PPROCESS_MEMORY_COUNTERS ,
    DWORD
    )

LATELOAD_FUNC_2(FALSE,
BOOL,
WINAPI,
GetPerformanceInfo,
    PPERFORMANCE_INFORMATION ,
    DWORD
    )

LATELOAD_FUNC_2(FALSE,
BOOL,
WINAPI,
EnumPageFilesW,
    PENUM_PAGE_FILE_CALLBACKW ,
    LPVOID
    )

LATELOAD_FUNC_2(FALSE,
BOOL,
WINAPI,
EnumPageFilesA,
    PENUM_PAGE_FILE_CALLBACKA ,
    LPVOID
    )

LATELOAD_FUNC_3(((DWORD)-1),
DWORD,
WINAPI,
GetProcessImageFileNameA,
     __in HANDLE,
    __out_ecount(nSize) LPSTR,
    __in DWORD
    )

LATELOAD_FUNC_3(((DWORD)-1),
DWORD,
WINAPI,
GetProcessImageFileNameW,
    __in HANDLE,
    __out_ecount(nSize) LPWSTR,
    __in DWORD   
	)

LATELOAD_END_CLASS()
