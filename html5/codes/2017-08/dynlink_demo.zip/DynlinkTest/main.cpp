#include "stdafx.h"

// A function called from a stub. If this is declared here it can of course
// also be used in the include files psapixx.h or psapix.h in as return
// value of individual entries. 
// This is, however hardly necessary as through p_symbol it allows returning
// function-specific values.
// However, there is no way to get to the parameters passed to the function
// as of now
class CDynlinkSymbol;

template<class T> T _s_stub_error(CDynlinkSymbol * p_symbol)
{
	printf("  ----: STUB called: Return type '%s', symbol name '%s'\n", typeid(T).name(), p_symbol ->get_name());
	return (DWORD) -1;
}


#define DYNLINK_DEFINE
#include <psapix.h>

#ifndef DYNLINK_LINK_IMPLICIT
	// When using explicit loading, we also include a prefixed version of the
	// library.
	// This means that all function names will be modified by prepending a 
	// prefix defined by DYNLINK_PREFIX.
	// CAREFUL: The header must be included in all files using the prefixed 
	// version with the same value assigned to the DYNLINK_PREFIX macro. See
	// test_dynlink.cpp for comparison
#	define DYNLINK_PREFIX S_
	
	// The following macros can be defined inside the header or outside. They
	// are only used when DYNLINK_DEFINE is defined - i.e. where the symbols 
	// are actually defined.
	// Therefore it is ok to have them here and not in test_dynlink.cpp

	// Use stubs for this import
#	define DYNLINK_USE_STUBS

	// Instead of simply returning a value, all stubs of functions without a
	// function specific return values (i.e. those declared with 
	// DYNLINK_DECLARE, not DYNLINK_DECLARE_EX) will call this function and
	// return its return value.
#	define DYNLINK_RETVAL_DWORD _s_stub_error<DWORD>(p_symbol)
#	define DYNLINK_RETVAL_int   _s_stub_error<int>(p_symbol)

	// .. or a simple return value indicating that the stub was called
#	define DYNLINK_RETVAL_BOOL  FALSE
#	include <psapixx.h>
#endif

void test_dynlink();
void test_dynamic();
void test_lateload();

// This file just loads the libraries and calls dynlink_test() which is defined 
// in test.cpp
int _tmain(int argc, _TCHAR* argv[])
{
	try
	{
		test_dynamic();
		test_lateload();
		test_dynlink();
	}
	catch(std::exception &e)
	{
		printf(e.what());
	}
	
}
