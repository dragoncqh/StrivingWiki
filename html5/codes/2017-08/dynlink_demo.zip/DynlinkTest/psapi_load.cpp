#include "stdafx.h"
#include "psapi_load.h"

EnumProcesses_t pEnumProcesses= NULL;
EnumProcessModules_t pEnumProcessModules= NULL;
EnumProcessModulesEx_t pEnumProcessModulesEx= NULL;
GetModuleBaseNameA_t pGetModuleBaseNameA= NULL;
GetModuleBaseNameW_t pGetModuleBaseNameW= NULL;
GetModuleFileNameExA_t pGetModuleFileNameExA= NULL;
GetModuleFileNameExW_t pGetModuleFileNameExW= NULL;
GetModuleInformation_t pGetModuleInformation= NULL;
EmptyWorkingSet_t pEmptyWorkingSet= NULL;
GetWsChanges_t pGetWsChanges= NULL;
GetWsChangesEx_t pGetWsChangesEx= NULL;
GetMappedFileNameW_t pGetMappedFileNameW= NULL;
GetMappedFileNameA_t pGetMappedFileNameA= NULL;
EnumDeviceDrivers_t pEnumDeviceDrivers= NULL;
GetDeviceDriverBaseNameA_t pGetDeviceDriverBaseNameA= NULL;
GetDeviceDriverBaseNameW_t pGetDeviceDriverBaseNameW= NULL;
GetDeviceDriverFileNameA_t pGetDeviceDriverFileNameA= NULL;
GetDeviceDriverFileNameW_t pGetDeviceDriverFileNameW= NULL;
GetProcessMemoryInfo_t pGetProcessMemoryInfo= NULL;
GetPerformanceInfo_t pGetPerformanceInfo= NULL;
EnumPageFilesW_t pEnumPageFilesW= NULL;
EnumPageFilesA_t pEnumPageFilesA= NULL;
GetProcessImageFileNameA_t pGetProcessImageFileNameA= NULL;
GetProcessImageFileNameW_t pGetProcessImageFileNameW= NULL;

int psapi_load()
{	
	HMODULE hDll = LoadLibrary(_T("psapi.dll"));
	if (! hDll)
		return 0;

	bool b_ok = true;
	b_ok &= NULL != (pEnumProcesses = (EnumProcesses_t) GetProcAddress(hDll, "EnumProcesses"));
	b_ok &= NULL != (pEnumProcessModules = (EnumProcessModules_t) GetProcAddress(hDll, "EnumProcessModules"));
	b_ok &= NULL != (pEnumProcessModulesEx = (EnumProcessModulesEx_t) GetProcAddress(hDll, "EnumProcessModulesEx"));
	b_ok &= NULL != (pGetModuleBaseNameA = (GetModuleBaseNameA_t) GetProcAddress(hDll, "GetModuleBaseNameA"));
	b_ok &= NULL != (pGetModuleBaseNameW = (GetModuleBaseNameW_t) GetProcAddress(hDll, "GetModuleBaseNameW"));
	b_ok &= NULL != (pGetModuleFileNameExA = (GetModuleFileNameExA_t) GetProcAddress(hDll, "GetModuleFileNameExA"));
	b_ok &= NULL != (pGetModuleFileNameExW = (GetModuleFileNameExW_t) GetProcAddress(hDll, "GetModuleFileNameExW"));
	b_ok &= NULL != (pGetModuleInformation = (GetModuleInformation_t) GetProcAddress(hDll, "GetModuleInformation"));
	b_ok &= NULL != (pEmptyWorkingSet = (EmptyWorkingSet_t) GetProcAddress(hDll, "EmptyWorkingSet"));
	b_ok &= NULL != (pGetWsChanges = (GetWsChanges_t) GetProcAddress(hDll, "GetWsChanges"));
	b_ok &= NULL != (pGetWsChangesEx = (GetWsChangesEx_t) GetProcAddress(hDll, "GetWsChangesEx"));
	b_ok &= NULL != (pGetMappedFileNameW = (GetMappedFileNameW_t) GetProcAddress(hDll, "GetMappedFileNameW"));
	b_ok &= NULL != (pGetMappedFileNameA = (GetMappedFileNameA_t) GetProcAddress(hDll, "GetMappedFileNameA"));
	b_ok &= NULL != (pEnumDeviceDrivers = (EnumDeviceDrivers_t) GetProcAddress(hDll, "EnumDeviceDrivers"));
	b_ok &= NULL != (pGetDeviceDriverBaseNameA = (GetDeviceDriverBaseNameA_t) GetProcAddress(hDll, "GetDeviceDriverBaseNameA"));
	b_ok &= NULL != (pGetDeviceDriverBaseNameW = (GetDeviceDriverBaseNameW_t) GetProcAddress(hDll, "GetDeviceDriverBaseNameW"));
	b_ok &= NULL != (pGetDeviceDriverFileNameA = (GetDeviceDriverFileNameA_t) GetProcAddress(hDll, "GetDeviceDriverFileNameA"));
	b_ok &= NULL != (pGetDeviceDriverFileNameW = (GetDeviceDriverFileNameW_t) GetProcAddress(hDll, "GetDeviceDriverFileNameW"));
	b_ok &= NULL != (pGetProcessMemoryInfo = (GetProcessMemoryInfo_t) GetProcAddress(hDll, "GetProcessMemoryInfo"));
	b_ok &= NULL != (pGetPerformanceInfo = (GetPerformanceInfo_t) GetProcAddress(hDll, "GetPerformanceInfo"));
	b_ok &= NULL != (pEnumPageFilesW = (EnumPageFilesW_t) GetProcAddress(hDll, "EnumPageFilesW"));
	b_ok &= NULL != (pEnumPageFilesA = (EnumPageFilesA_t) GetProcAddress(hDll, "EnumPageFilesA"));
	b_ok &= NULL != (pGetProcessImageFileNameA = (GetProcessImageFileNameA_t) GetProcAddress(hDll, "GetProcessImageFileNameA"));
	b_ok &= NULL != (pGetProcessImageFileNameW = (GetProcessImageFileNameW_t) GetProcAddress(hDll, "GetProcessImageFileNameW"));

	return b_ok ? 1 : 2;
}