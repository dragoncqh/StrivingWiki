// DynlinkTest.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"

#ifdef _DEBUG
#define ASSERT(f) if (!(f)) DebugBreak();
#else
#define ASSERT(f)
#endif

#include "psapi_lateload.h"

void test_lateload()
{
	_tprintf(_T("--TEST: Traditional dynamic loading (explicit)\r\n"));

	CPsapiWrapper psapi;
	// Not loaded yet:
	TEST(psapi.dll_IsLoaded() == false);

	// Test for presence of a symbol
	TEST(psapi.Is_EnumProcesses() == TRUE);
	TEST(psapi.dll_IsLoaded() == TRUE);

	TCHAR sName1[1024];
	#ifdef UNICODE
		TEST(psapi.GetProcessImageFileNameW(GetCurrentProcess(), sName1, 1024) > 0);
	#else
		TEST(psapi.GetProcessImageFileNameA(GetCurrentProcess(), sName1, 1024) > 0);
	#endif

	_tprintf(_T("  exe path: %s\r\n"), sName1);
	_tprintf(_T("SUCCESS: ALL TESTS PASSED\r\n\r\n"));
}