// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

//#define DYNLINK_LINK_IMPLICIT

#include <windows.h>
#include <stdio.h>
#include <tchar.h>
#include <exception>

// our very simple test macro
#define TEST(expr)	\
	_s_test_expression((expr), #expr);


static void _s_test_expression(bool result, const char * s_expr)
{
	if (result)
	{
		printf("  (ok): %s\n", s_expr);
	}
	else
	{
		char buf[1024];
		sprintf_s(buf, "  ERROR: '%s' failed!\n", s_expr);
		throw std::exception(buf);
	}
}